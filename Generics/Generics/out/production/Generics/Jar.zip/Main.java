import java.util.ArrayDeque;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

       Jar <Integer> jar = new Jar<>();

        jar.add(13);
        jar.add(15);
        jar.add(17);
      int removed =  jar.remove();
        System.out.println(removed);
    }

}
