package Google;

public class Company {
    String companyName;
    String department;
    double salary;

  /*  public Company(String companyName, String department, double salary) {
        this.companyName = companyName;
        this.department = department;
        this.salary = salary;
    }*/
}
