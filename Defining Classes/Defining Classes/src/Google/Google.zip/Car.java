package Google;

public class Car {
    String carModel;
    String carSpeed;


}
