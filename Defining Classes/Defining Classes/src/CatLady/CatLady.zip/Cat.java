package CatLady;

public class Cat {
    String breed;
    String name;
    double characteristic;

    public Cat(String breed, String name, double characteristic) {
        this.breed = breed;
        this.name = name;
        this.characteristic = characteristic;
    }
}
